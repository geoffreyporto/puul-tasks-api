# CarPuul

Owner: Geoffrey Porto

[Database](CarPuul%202214fbea3fce8080ad44f374027b3cfb/Database%202234fbea3fce80f3aae5d330dc5a436d.md)

[Puul - BackEnd API Tech Standards](CarPuul%202214fbea3fce8080ad44f374027b3cfb/Puul%20-%20BackEnd%20API%20Tech%20Standards%202214fbea3fce80d6be2fd1719bbc8d0e.md)

[APIs de Analitica](CarPuul%202214fbea3fce8080ad44f374027b3cfb/APIs%20de%20Analitica%202244fbea3fce8031a813ec9e618643c9.md)

[Readme](CarPuul%202214fbea3fce8080ad44f374027b3cfb/Readme%202214fbea3fce80318871d08a111a22f3.md)

[📚 Integraciones: temporal.io](CarPuul%202214fbea3fce8080ad44f374027b3cfb/%F0%9F%93%9A%20Integraciones%20temporal%20io%202214fbea3fce80f0b044f01fa141abe3.md)

[Pensamento](CarPuul%202214fbea3fce8080ad44f374027b3cfb/Pensamento%202214fbea3fce8028a1f6fd1203a2c8a8.md)