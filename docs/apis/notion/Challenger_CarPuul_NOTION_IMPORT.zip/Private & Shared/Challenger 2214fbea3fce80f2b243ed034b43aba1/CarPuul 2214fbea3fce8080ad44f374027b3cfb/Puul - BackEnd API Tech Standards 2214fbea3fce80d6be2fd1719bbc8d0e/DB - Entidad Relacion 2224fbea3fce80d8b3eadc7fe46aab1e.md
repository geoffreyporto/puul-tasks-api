# DB - Entidad Relacion

Owner: Geoffrey Porto

**Formato: Diagrama**

![ERDB-Mermaid Chart-2025-06-30-013450.png](DB%20-%20Entidad%20Relacion%202224fbea3fce80d8b3eadc7fe46aab1e/ERDB-Mermaid_Chart-2025-06-30-013450.png)

**Formato:** Mermaid

erDiagram
%% =====================================================
%% DIAGRAMA ENTIDAD-RELACIÓN - PUUL TASKS API
%% Base de Datos: Supabase PostgreSQL 15.8
%% =====================================================

```
%% Entidades Principales
USERS {
    uuid id PK
    varchar email UK "UNIQUE, NOT NULL"
    varchar name "NOT NULL"
    user_role role "DEFAULT 'member'"
    varchar password_hash "NULL for OAuth"
    text avatar_url
    varchar phone
    varchar timezone "DEFAULT 'UTC'"
    boolean is_active "DEFAULT true"
    timestamptz last_login_at
    timestamptz email_verified_at
    timestamptz created_at "DEFAULT NOW()"
    timestamptz updated_at "DEFAULT NOW()"
    uuid created_by FK
    uuid updated_by FK
}

TEAMS {
    uuid id PK
    varchar name "NOT NULL"
    text description
    varchar slug UK "UNIQUE, NOT NULL"
    boolean is_active "DEFAULT true"
    jsonb settings "DEFAULT '{}'"
    timestamptz created_at "DEFAULT NOW()"
    timestamptz updated_at "DEFAULT NOW()"
    uuid created_by FK
}

TEAM_MEMBERSHIPS {
    uuid id PK
    uuid user_id FK "NOT NULL"
    uuid team_id FK "NOT NULL"
    user_role role "DEFAULT 'member'"
    timestamptz joined_at "DEFAULT NOW()"
    boolean is_active "DEFAULT true"
}

TASK_CATEGORIES {
    uuid id PK
    varchar name "NOT NULL"
    text description
    varchar color "DEFAULT '#3B82F6'"
    uuid team_id FK
    boolean is_active "DEFAULT true"
    timestamptz created_at "DEFAULT NOW()"
    timestamptz updated_at "DEFAULT NOW()"
    uuid created_by FK
}

TASKS {
    uuid id PK
    varchar title "NOT NULL, 3-500 chars"
    text description
    decimal estimated_hours "NOT NULL, > 0"
    decimal actual_hours "DEFAULT 0, >= 0"
    decimal cost "NOT NULL, >= 0"
    timestamptz due_date "NOT NULL"
    task_status status "DEFAULT 'active'"
    task_priority priority "DEFAULT 'medium'"
    uuid category_id FK
    uuid team_id FK
    uuid parent_task_id FK "Self reference"
    timestamptz started_at
    timestamptz completed_at
    timestamptz created_at "DEFAULT NOW()"
    timestamptz updated_at "DEFAULT NOW()"
    uuid created_by FK "NOT NULL"
    uuid updated_by FK
    integer assignee_count "DEFAULT 0, Calculated"
    decimal completion_percentage "0-100, Calculated"
}

TASK_ASSIGNMENTS {
    uuid id PK
    uuid task_id FK "NOT NULL"
    uuid user_id FK "NOT NULL"
    timestamptz assigned_at "DEFAULT NOW()"
    uuid assigned_by FK "NOT NULL"
    boolean is_primary "DEFAULT false"
    decimal hours_allocated "> 0"
    text notes
    timestamptz accepted_at
    timestamptz completed_at
    boolean is_active "DEFAULT true"
}

%% Entidades de Notificaciones
NOTIFICATIONS {
    uuid id PK
    uuid user_id FK "NOT NULL"
    varchar title "NOT NULL"
    text message "NOT NULL"
    notification_type type "NOT NULL"
    notification_channel channel "NOT NULL"
    notification_status status "DEFAULT 'pending'"
    uuid task_id FK
    uuid related_user_id FK
    timestamptz scheduled_for "DEFAULT NOW()"
    timestamptz sent_at
    timestamptz delivered_at
    timestamptz failed_at
    text error_message
    varchar workflow_id "Temporal.io"
    varchar workflow_run_id "Temporal.io"
    timestamptz read_at
    timestamptz clicked_at
    timestamptz created_at "DEFAULT NOW()"
}

NOTIFICATION_TEMPLATES {
    uuid id PK
    varchar name UK "UNIQUE, NOT NULL"
    notification_type type "NOT NULL"
    notification_channel channel "NOT NULL"
    text subject_template "NOT NULL"
    text body_template "NOT NULL"
    jsonb variables "DEFAULT '[]'"
    boolean is_active "DEFAULT true"
    timestamptz created_at "DEFAULT NOW()"
    timestamptz updated_at "DEFAULT NOW()"
    uuid created_by FK
}

%% Entidades de Auditoría
ACTIVITY_LOGS {
    uuid id PK
    uuid user_id FK
    varchar action "NOT NULL"
    varchar resource_type "NOT NULL"
    uuid resource_id
    jsonb old_values
    jsonb new_values
    jsonb changes
    inet ip_address
    text user_agent
    varchar session_id
    timestamptz occurred_at "DEFAULT NOW()"
}

USER_SESSIONS {
    uuid id PK
    uuid user_id FK "NOT NULL"
    varchar session_token UK "UNIQUE, NOT NULL"
    varchar refresh_token UK
    inet ip_address
    text user_agent
    jsonb device_info
    timestamptz created_at "DEFAULT NOW()"
    timestamptz last_activity_at "DEFAULT NOW()"
    timestamptz expires_at "NOT NULL"
    boolean is_active "DEFAULT true"
    timestamptz revoked_at
    uuid revoked_by FK
}

%% Entidades de Configuración
SYSTEM_SETTINGS {
    uuid id PK
    varchar key UK "UNIQUE, NOT NULL"
    jsonb value "NOT NULL"
    text description
    boolean is_public "DEFAULT false"
    timestamptz created_at "DEFAULT NOW()"
    timestamptz updated_at "DEFAULT NOW()"
    uuid updated_by FK
}

GENERATED_REPORTS {
    uuid id PK
    varchar name "NOT NULL"
    varchar type "NOT NULL"
    jsonb parameters "DEFAULT '{}'"
    uuid team_id FK
    jsonb data "NOT NULL"
    text file_url
    timestamptz generated_at "DEFAULT NOW()"
    uuid generated_by FK
    varchar workflow_id "Temporal.io"
    boolean is_public "DEFAULT false"
    timestamptz expires_at
}

%% Entidades de Contenido
TASK_COMMENTS {
    uuid id PK
    uuid task_id FK "NOT NULL"
    uuid user_id FK "NOT NULL"
    text content "NOT NULL, 1-5000 chars"
    boolean is_internal "DEFAULT false"
    uuid parent_comment_id FK "Self reference"
    timestamptz created_at "DEFAULT NOW()"
    timestamptz updated_at "DEFAULT NOW()"
}

TASK_ATTACHMENTS {
    uuid id PK
    uuid task_id FK "NOT NULL"
    uuid uploaded_by FK "NOT NULL"
    varchar filename "NOT NULL"
    varchar original_filename "NOT NULL"
    bigint file_size "NOT NULL, <= 50MB"
    varchar mime_type "NOT NULL"
    text file_url "NOT NULL"
    timestamptz uploaded_at "DEFAULT NOW()"
}

%% =====================================================
%% RELACIONES PRINCIPALES
%% =====================================================

%% Relaciones de Usuario
USERS ||--o{ TEAM_MEMBERSHIPS : "belongs to teams"
TEAMS ||--o{ TEAM_MEMBERSHIPS : "has members"
USERS ||--o{ USER_SESSIONS : "has sessions"
USERS ||--o{ ACTIVITY_LOGS : "performs actions"

%% Relaciones de Equipos
TEAMS ||--o{ TASK_CATEGORIES : "owns categories"
TEAMS ||--o{ TASKS : "owns tasks"
TEAMS ||--o{ GENERATED_REPORTS : "generates reports"

%% Relaciones de Tareas (Core)
USERS ||--o{ TASKS : "creates tasks"
TASK_CATEGORIES ||--o{ TASKS : "categorizes"
TASKS ||--o{ TASKS : "has subtasks"
TASKS ||--o{ TASK_ASSIGNMENTS : "assigned to users"
USERS ||--o{ TASK_ASSIGNMENTS : "assigned tasks"
USERS ||--o{ TASK_ASSIGNMENTS : "assigns tasks (assigned_by)"

%% Relaciones de Contenido de Tareas
TASKS ||--o{ TASK_COMMENTS : "has comments"
USERS ||--o{ TASK_COMMENTS : "writes comments"
TASK_COMMENTS ||--o{ TASK_COMMENTS : "has replies"
TASKS ||--o{ TASK_ATTACHMENTS : "has attachments"
USERS ||--o{ TASK_ATTACHMENTS : "uploads files"

%% Relaciones de Notificaciones
USERS ||--o{ NOTIFICATIONS : "receives notifications"
TASKS ||--o{ NOTIFICATIONS : "triggers notifications"
USERS ||--o{ NOTIFICATIONS : "triggers notifications (related_user)"
USERS ||--o{ NOTIFICATION_TEMPLATES : "creates templates"

%% Relaciones de Configuración
USERS ||--o{ SYSTEM_SETTINGS : "updates settings"
USERS ||--o{ GENERATED_REPORTS : "generates reports"

%% Relaciones de Creación/Actualización
USERS ||--o{ USERS : "creates/updates users"
USERS ||--o{ TEAMS : "creates teams"
USERS ||--o{ TASK_CATEGORIES : "creates categories"
USERS ||--o{ TASKS : "updates tasks"
USERS ||--o{ NOTIFICATION_TEMPLATES : "manages templates"
USERS ||--o{ USER_SESSIONS : "revokes sessions"

%% =====================================================
%% NOTAS IMPORTANTES
%% =====================================================
%% 1. Todas las PKs son UUID v4 generadas automáticamente
%% 2. Row Level Security (RLS) habilitado en tablas principales
%% 3. Triggers automáticos para updated_at y logging
%% 4. Campos calculados actualizados via triggers
%% 5. Soporte para Temporal.io workflows en notificaciones
%% 6. Optimizado para Supabase PostgreSQL 15.8
%% 7. Multitenancy via teams (opcional)
%% 8. Auditoría completa de cambios
%% 9. Sistema de notificaciones multi-canal
%% 10. Soporte para jerarquías (subtareas, comentarios nested)

```