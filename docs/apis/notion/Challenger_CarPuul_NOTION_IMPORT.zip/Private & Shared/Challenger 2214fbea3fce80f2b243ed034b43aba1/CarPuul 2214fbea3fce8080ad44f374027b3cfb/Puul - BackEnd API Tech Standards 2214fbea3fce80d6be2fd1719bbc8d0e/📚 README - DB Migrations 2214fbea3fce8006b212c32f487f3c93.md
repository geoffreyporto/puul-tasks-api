# 📚 README - DB Migrations

Owner: Geoffrey Porto

# Migraciones de Base de Datos - Puul Tasks API

### **Base de datos Supabase postgresql**

![image.png](%F0%9F%93%9A%20README%20-%20DB%20Migrations%202214fbea3fce8006b212c32f487f3c93/image.png)

## Estructura de Archivos

Las migraciones están organizadas en 12 archivos independientes que deben ejecutarse en orden:

```
supabase/migrations/
├── 20241201000001_initial_setup.sql
├── 20241201000002_create_users_table.sql
├── 20241201000003_create_teams_table.sql
├── 20241201000004_create_team_memberships_table.sql
├── 20241201000005_create_task_categories_table.sql
├── 20241201000006_create_tasks_table.sql
├── 20241201000007_create_task_assignments_table.sql
├── 20241201000008_create_notifications_tables.sql
├── 20241201000009_create_audit_tables.sql
├── 20241201000010_create_triggers_and_functions.sql
├── 20241201000011_create_policies_and_views.sql
└── 20241201000012_insert_initial_data.sql

```

## Descripción de Cada Archivo

### 1. `20241201000001_initial_setup.sql`

- **Propósito**: Configuración inicial del sistema
- **Contiene**: Extensiones PostgreSQL, ENUMs, configuración de timezone
- **Dependencias**: Ninguna

### 2. `20241201000002_create_users_table.sql`

- **Propósito**: Tabla principal de usuarios
- **Contiene**: Tabla `users`, índices básicos, triggers para `updated_at`
- **Dependencias**: ENUMs del archivo 1

### 3. `20241201000003_create_teams_table.sql`

- **Propósito**: Gestión de equipos
- **Contiene**: Tabla `teams`, relaciones con `users`
- **Dependencias**: Tabla `users`

### 4. `20241201000004_create_team_memberships_table.sql`

- **Propósito**: Relación many-to-many entre usuarios y equipos
- **Contiene**: Tabla `team_memberships`
- **Dependencias**: Tablas `users` y `teams`

### 5. `20241201000005_create_task_categories_table.sql`

- **Propósito**: Categorización de tareas
- **Contiene**: Tabla `task_categories`
- **Dependencias**: Tablas `users` y `teams`

### 6. `20241201000006_create_tasks_table.sql`

- **Propósito**: Tabla principal de tareas
- **Contiene**: Tabla `tasks`, índices de performance, constraints de negocio
- **Dependencias**: Tablas `users`, `teams`, `task_categories`

### 7. `20241201000007_create_task_assignments_table.sql`

- **Propósito**: Asignaciones de usuarios a tareas
- **Contiene**: Tabla `task_assignments`, triggers para contadores automáticos
- **Dependencias**: Tablas `users` y `tasks`

### 8. `20241201000008_create_notifications_tables.sql`

- **Propósito**: Sistema de notificaciones
- **Contiene**: Tablas `notifications` y `notification_templates`
- **Dependencias**: Tablas `users` y `tasks`

### 9. `20241201000009_create_audit_tables.sql`

- **Propósito**: Auditoría y tablas auxiliares
- **Contiene**: `activity_logs`, `user_sessions`, `system_settings`, `generated_reports`, `task_comments`, `task_attachments`
- **Dependencias**: Tablas principales previas

### 10. `20241201000010_create_triggers_and_functions.sql`

- **Propósito**: Lógica de negocio automatizada
- **Contiene**: Funciones PL/pgSQL, triggers para logging automático, validaciones
- **Dependencias**: Todas las tablas principales

### 11. `20241201000011_create_policies_and_views.sql`

- **Propósito**: Seguridad y analítica
- **Contiene**: Políticas RLS para Supabase, vistas de estadísticas
- **Dependencias**: Todas las tablas

### 12. `20241201000012_insert_initial_data.sql`

- **Propósito**: Datos iniciales y configuración final
- **Contiene**: Configuraciones del sistema, templates de notificación, categorías predeterminadas
- **Dependencias**: Todas las estructuras anteriores

## Instalación con Supabase CLI

### Prerequisitos

```bash
# Instalar Supabase CLI
npm install -g supabase

# Verificar instalación
supabase --version

```

### Inicializar Proyecto Supabase

```bash
# Crear directorio del proyecto
mkdir puul-tasks-api
cd puul-tasks-api

# Inicializar proyecto Supabase
supabase init

```

**Login a Supabase**

```bash
# Login a Supabase
supabase login
```

![image.png](%F0%9F%93%9A%20README%20-%20DB%20Migrations%202214fbea3fce8006b212c32f487f3c93/image%201.png)

```bash
# Output: Especifique el Token de la pagina web de Supabase
Hello from Supabase! Press Enter to open browser and login automatically.

Here is your login link in case browser did not open https://supabase.com/dashboard/cli/login?session_id=75e9e7b2-04ea-401b-a3c7-bb1f29fd6942&token_name=cli_geoffreyporto@Mac-Studio-de-Geoffrey.local_1751232276&public_key=040061f9fff7c6f05992cb9ef1b1f5356d3dabc31a30986a8274fbbd1bb428a85924e09af2aa3e1c99e1d0b65a412322547e32a544adedd726c2053ead2cc4df33

**Enter your verification code:** e5eaa….
```

**Logueado exitosamente:**

```bash
Token cli_geoffreyporto@Mac-Studio-de-Geoffrey.local_1751232276 created successfully.
You are now logged in. Happy coding!
```

**Conectar con supabase**

```bash
# Configurar proyecto (opcional - para proyectos existentes)
supabase link --project-ref <YOUR SUPBASE PROJECT>
Enter your database password (or leave blank to skip): <YOUR PASSOWORD>
```

```bash
**# Output:**

WARNING: Local config differs from linked project. Try updating supabase/config.toml
diff supabase/config.toml <YOUR SUPBASE PROJECT>
--- supabase/config.toml
+++ <YOUR SUPBASE PROJECT>
@@ -13,7 +13,7 @@
 [db]
 port = 54322
 shadow_port = 54320
-major_version = 17
+major_version = 15
 root_key = ""
 [db.pooler]
 enabled = false
@@ -54,8 +54,8 @@

 [auth]
 enabled = true
-site_url = "http://127.0.0.1:3000"
-additional_redirect_urls = ["https://127.0.0.1:3000"]
+site_url = "http://localhost:3000"
+additional_redirect_urls = []
 jwt_expiry = 3600
 enable_refresh_token_rotation = true
 refresh_token_reuse_interval = 10
@@ -96,9 +96,9 @@
 [auth.email]
 enable_signup = true
 double_confirm_changes = true
-enable_confirmations = false
+enable_confirmations = true
 secure_password_change = false
-max_frequency = "1s"
+max_frequency = "1m0s"
 otp_length = 6
 otp_expiry = 3600
 [auth.email.template]
```

### Ejecutar Migraciones

## 1. `supabase db diff`

Compara el esquema de tu base de datos local (según tus migraciones) con el esquema real de tu proyecto remoto, y genera un SQL de diferencias.

```bash

# Muestra las diferencias entre el esquema local y el remoto
supabase db diff

# Opcionalmente redirige el SQL resultante a un archivo
supabase db diff > diff.sql
```

---

## 2. `supabase db dump`

Vuelca (“dump”) datos y/o definiciones de esquema desde tu base de datos remota a archivos `.sql`.

```bash

# Volcar sólo el esquema (sin datos) desde el remoto
supabase db dump --schema-only

# Volcar esquema y datos en un solo archivo
supabase db dump --data-only

# Volcar todo (esquema + datos) en dump.sql
supabase db dump > dump.sql
```

---

## 3. Creacion de la base de datos (manual - Default)

**Variable de conexion**

```bash
export DATABASE_URL="postgresql://postgres:TU_PASS@db.mi-proyecto.supabase.co:5432/postgres"
```

**DB Local**

Valida tu código SQL local (en `supabase/migrations/`) para detectar errores de tipado, palabras reservadas o sintaxis incompatible con Postgres.

```bash

# Ejecuta el chequeo de SQL en todas tus migraciones
supabase db lint

# Si hay errores, verás en consola línea y archivo donde corregir
```

---

**DB Remoto**

```bash
supabase db lint --db-url "postgresql://postgres:<TU_PASSWORD>@db.<TU_PROYECTO>.supabase.co:5432/postgres"
```

**Ejecutando scripts**

**creando setup inicial**

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000001_initial_setup.sql
#psql -h db.hhywwjurdzwieldploou.supabase.co -p 5432 -d postgres -U postgres

#output:

(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000001_initial_setup.sql
psql:supabase/migrations/DDL/20241201000001_initial_setup.sql:7: NOTICE:  extension "uuid-ossp" already exists, skipping
CREATE EXTENSION
psql:supabase/migrations/DDL/20241201000001_initial_setup.sql:8: NOTICE:  extension "pgcrypto" already exists, skipping
CREATE EXTENSION
CREATE EXTENSION
SET
CREATE TYPE
CREATE TYPE
CREATE TYPE
CREATE TYPE
CREATE TYPE
CREATE TYPE
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando tabla de usuarios:**

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000002_create_users_table.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000002_create_users_table.sql
CREATE TABLE
ALTER TABLE
ALTER TABLE
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE FUNCTION
CREATE TRIGGER
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando tabla de teams:**

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000003_create_teams_table.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000003_create_teams_table.sql
CREATE TABLE
ALTER TABLE
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE TRIGGER
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando tabla de teams members:**

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000004_create_team_memberships_table.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000004_create_team_memberships_table.sql
CREATE TABLE
ALTER TABLE
ALTER TABLE
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando tabla de task categories:**

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000005_create_task_categories_table.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000004_create_team_memberships_table.sql
CREATE TABLE
ALTER TABLE
ALTER TABLE
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando tabla de task categories:**

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000006_create_tasks_table.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000006_create_tasks_table.sql
CREATE TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE TRIGGER
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando tabla de task** assignments**:**

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000007_create_task_assignments_table.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000007_create_task_assignments_table.sql

CREATE TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE FUNCTION
CREATE TRIGGER
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando tabla de** notifications:

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000008_create_notifications_tables.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000008_create_notifications_tables.sql
CREATE TABLE
CREATE TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE TRIGGER
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando tabla de** auditorias:

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000009_create_audit_tables.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000009_create_audit_tables.sql
CREATE TABLE
CREATE TABLE
CREATE TABLE
CREATE TABLE
CREATE TABLE
CREATE TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
ALTER TABLE
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE TRIGGER
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando** triggers:

- log_task_changes() IS 'Registra automáticamente cambios en tareas para auditoría';
- log_task_assignment_changes() IS 'Registra cambios en asignaciones de tareas';
- validate_primary_assignment() IS 'Valida que solo haya una asignación primaria por tarea';
- check_task_completion() IS 'Auto-completa tareas cuando todas sus asignaciones están completas';
- calculate_user_stats(UUID) IS 'Calcula estadísticas de usuario en tiempo real';

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000010_create_triggers_and_functions.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000010_create_triggers_and_functions.sql
CREATE FUNCTION
CREATE TRIGGER
CREATE FUNCTION
CREATE TRIGGER
CREATE FUNCTION
CREATE FUNCTION
CREATE TRIGGER
CREATE FUNCTION
CREATE TRIGGER
CREATE FUNCTION
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando policies**:

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000011_create_policies_and_views.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000010_create_triggers_and_functions.sql

CREATE FUNCTION "log_task_changes_trigger" for relation "tasks" 
CREATE FUNCTION "log_task_assignment_changes_trigger" for relation "task_assignments"
CREATE FUNCTION
CREATE FUNCTION "validate_primary_assignment_trigger" for relation "task_assignments" 
CREATE FUNCTION "check_task_completion_trigger" for relation "task_assignments"
CREATE FUNCTION
COMMENT
COMMENT
COMMENT
COMMENT
COMMENT
```

**Creando policies**:

```bash
psql "$DATABASE_URL" -f supabase/migrations/DML/20241201000012_insert_initial_data.sql

#output:
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/DML/20241201000012_insert_initial_data.sql
INSERT 0 13
INSERT 0 6
INSERT 0 10
INSERT 0 1
COMMENT
INSERT 0 1
psql:supabase/migrations/DML/20241201000012_insert_initial_data.sql:261: NOTICE:  Migración completada exitosamente:
psql:supabase/migrations/DML/20241201000012_insert_initial_data.sql:261: NOTICE:  - Tablas creadas: 14
psql:supabase/migrations/DML/20241201000012_insert_initial_data.sql:261: NOTICE:  - Vistas creadas: 0
psql:supabase/migrations/DML/20241201000012_insert_initial_data.sql:261: NOTICE:  - Funciones creadas: 95
psql:supabase/migrations/DML/20241201000012_insert_initial_data.sql:261: NOTICE:  - Base de datos Puul Tasks API lista para usar.
DO
                                      status                                      |         completed_at
----------------------------------------------------------------------------------+-------------------------------
 Migración completada exitosamente. Base de datos Puul Tasks API lista para usar. | 2025-06-30 00:05:14.322695+00
(1 fila)

```

**Creando policies avanzadas, segurida, etc..**:

```bash
psql "$DATABASE_URL" -f supabase/migrations/DDL/20241201000002_initial_advanced_setup.sql
```

## 4. Validación de la base de datos

```bash
 psql "$DATABASE_URL" -f supabase/migrations/validate_migrations.sql
```

**Salida:**

```bash
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % psql "$DATABASE_URL" -f supabase/migrations/validate_migrations.sql
🔍 Iniciando validación de migraciones...
📦 Verificando extensiones...
 extension_name | status
----------------+--------
 btree_gin      | ✅
 pgcrypto       | ✅
 uuid-ossp      | ✅
(3 filas)

🏷️  Verificando tipos enumerados...
      enum_name       |                                                 values                                                  | status
----------------------+---------------------------------------------------------------------------------------------------------+--------
 notification_channel | {email,sms,in_app,slack,teams}                                                                          | ✅
 notification_status  | {pending,sent,delivered,failed,cancelled}                                                               | ✅
 notification_type    | {REMINDER_3_DAYS,REMINDER_1_DAY,DUE_TODAY,OVERDUE,ESCALATION,TASK_ASSIGNED,TASK_COMPLETED,TASK_UPDATED} | ✅
 task_priority        | {low,medium,high,urgent}                                                                                | ✅
 task_status          | {active,completed,cancelled,on_hold}                                                                    | ✅
 user_role            | {member,admin}                                                                                          | ✅
(6 filas)

📋 Verificando tablas...
psql:supabase/migrations/validate_migrations.sql:66: ERROR:  column "column_count" does not exist
LÍNEA 16:         (SELECT column_count FROM information_schema.tables ...
                          ^
🔗 Verificando foreign keys...
       table_name       |           constraint_name            |    column_name    | referenced_table | referenced_column | status
------------------------+--------------------------------------+-------------------+------------------+-------------------+--------
 activity_logs          | fk_activity_logs_user_id             | user_id           | users            | id                | ✅
 generated_reports      | fk_generated_reports_generated_by    | generated_by      | users            | id                | ✅
 generated_reports      | fk_generated_reports_team_id         | team_id           | teams            | id                | ✅
 notification_templates | fk_notification_templates_created_by | created_by        | users            | id                | ✅
 notifications          | fk_notifications_related_user_id     | related_user_id   | users            | id                | ✅
 notifications          | fk_notifications_task_id             | task_id           | tasks            | id                | ✅
 notifications          | fk_notifications_user_id             | user_id           | users            | id                | ✅
 system_settings        | fk_system_settings_updated_by        | updated_by        | users            | id                | ✅
 task_assignments       | fk_task_assignments_assigned_by      | assigned_by       | users            | id                | ✅
 task_assignments       | fk_task_assignments_task_id          | task_id           | tasks            | id                | ✅
 task_assignments       | fk_task_assignments_user_id          | user_id           | users            | id                | ✅
 task_attachments       | fk_task_attachments_task_id          | task_id           | tasks            | id                | ✅
 task_attachments       | fk_task_attachments_uploaded_by      | uploaded_by       | users            | id                | ✅
 task_categories        | fk_task_categories_created_by        | created_by        | users            | id                | ✅
 task_categories        | fk_task_categories_team_id           | team_id           | teams            | id                | ✅
 task_comments          | fk_task_comments_parent_comment_id   | parent_comment_id | task_comments    | id                | ✅
 task_comments          | fk_task_comments_task_id             | task_id           | tasks            | id                | ✅
 task_comments          | fk_task_comments_user_id             | user_id           | users            | id                | ✅
 tasks                  | fk_tasks_category_id                 | category_id       | task_categories  | id                | ✅
 tasks                  | fk_tasks_created_by                  | created_by        | users            | id                | ✅
 tasks                  | fk_tasks_parent_task_id              | parent_task_id    | tasks            | id                | ✅
 tasks                  | fk_tasks_team_id                     | team_id           | teams            | id                | ✅
 tasks                  | fk_tasks_updated_by                  | updated_by        | users            | id                | ✅
 team_memberships       | fk_team_memberships_team_id          | team_id           | teams            | id                | ✅
 team_memberships       | fk_team_memberships_user_id          | user_id           | users            | id                | ✅
 teams                  | fk_teams_created_by                  | created_by        | users            | id                | ✅
 user_sessions          | fk_user_sessions_revoked_by          | revoked_by        | users            | id                | ✅
 user_sessions          | fk_user_sessions_user_id             | user_id           | users            | id                | ✅
 users                  | fk_users_created_by                  | created_by        | users            | id                | ✅
 users                  | fk_users_updated_by                  | updated_by        | users            | id                | ✅
(30 filas)

📇 Verificando índices...
 schemaname |       tablename        |                   indexname                    | status
------------+------------------------+------------------------------------------------+--------
 public     | activity_logs          | activity_logs_pkey                             | 🔑 PK
 public     | activity_logs          | idx_activity_logs_resource                     | ✅
 public     | activity_logs          | idx_activity_logs_time                         | ✅
 public     | activity_logs          | idx_activity_logs_user_id_time                 | ✅
 public     | generated_reports      | generated_reports_pkey                         | 🔑 PK
 public     | notification_templates | idx_notification_templates_active              | ✅
 public     | notification_templates | idx_notification_templates_type                | ✅
 public     | notification_templates | notification_templates_name_key                | 🔑 UK
 public     | notification_templates | notification_templates_pkey                    | 🔑 PK
 public     | notifications          | idx_notifications_pending                      | ✅
 public     | notifications          | idx_notifications_scheduled_for                | ✅
 public     | notifications          | idx_notifications_status                       | ✅
 public     | notifications          | idx_notifications_task_id                      | ✅
 public     | notifications          | idx_notifications_type_channel                 | ✅
 public     | notifications          | idx_notifications_user_id                      | ✅
 public     | notifications          | notifications_pkey                             | 🔑 PK
 public     | system_settings        | idx_system_settings_key                        | ✅
 public     | system_settings        | idx_system_settings_public                     | ✅
 public     | system_settings        | system_settings_key_key                        | 🔑 UK
 public     | system_settings        | system_settings_pkey                           | 🔑 PK
 public     | task_assignments       | idx_task_assignments_active                    | ✅
 public     | task_assignments       | idx_task_assignments_primary                   | ✅
 public     | task_assignments       | idx_task_assignments_task_id                   | ✅
 public     | task_assignments       | idx_task_assignments_task_user                 | ✅
 public     | task_assignments       | idx_task_assignments_user_id                   | ✅
 public     | task_assignments       | task_assignments_pkey                          | 🔑 PK
 public     | task_assignments       | task_assignments_task_id_user_id_is_active_key | 🔑 UK
 public     | task_attachments       | idx_task_attachments_task_id                   | ✅
 public     | task_attachments       | idx_task_attachments_uploaded_by               | ✅
 public     | task_attachments       | task_attachments_pkey                          | 🔑 PK
 public     | task_categories        | idx_task_categories_active                     | ✅
 public     | task_categories        | idx_task_categories_name                       | ✅
 public     | task_categories        | idx_task_categories_team_id                    | ✅
 public     | task_categories        | task_categories_pkey                           | 🔑 PK
 public     | task_comments          | idx_task_comments_task_id                      | ✅
 public     | task_comments          | idx_task_comments_user_id                      | ✅
 public     | task_comments          | task_comments_pkey                             | 🔑 PK
 public     | tasks                  | idx_tasks_category_id                          | ✅
 public     | tasks                  | idx_tasks_created_at                           | ✅
 public     | tasks                  | idx_tasks_created_by                           | ✅
 public     | tasks                  | idx_tasks_due_date                             | ✅
 public     | tasks                  | idx_tasks_status                               | ✅
 public     | tasks                  | idx_tasks_status_due_date                      | ✅
 public     | tasks                  | idx_tasks_team_id                              | ✅
 public     | tasks                  | idx_tasks_team_status                          | ✅
 public     | tasks                  | idx_tasks_title                                | ✅
 public     | tasks                  | tasks_pkey                                     | 🔑 PK
 public     | team_memberships       | idx_team_memberships_active                    | ✅
 public     | team_memberships       | idx_team_memberships_team_id                   | ✅
 public     | team_memberships       | idx_team_memberships_user_id                   | ✅
 public     | team_memberships       | idx_team_memberships_user_team                 | ✅
 public     | team_memberships       | team_memberships_pkey                          | 🔑 PK
 public     | team_memberships       | team_memberships_user_id_team_id_key           | 🔑 UK
 public     | teams                  | idx_teams_active                               | ✅
 public     | teams                  | idx_teams_created_by                           | ✅
 public     | teams                  | idx_teams_slug                                 | ✅
 public     | teams                  | teams_pkey                                     | 🔑 PK
 public     | teams                  | teams_slug_key                                 | 🔑 UK
 public     | user_sessions          | idx_user_sessions_active                       | ✅
 public     | user_sessions          | idx_user_sessions_expires_at                   | ✅
 public     | user_sessions          | idx_user_sessions_user_id                      | ✅
 public     | user_sessions          | user_sessions_pkey                             | 🔑 PK
 public     | user_sessions          | user_sessions_refresh_token_key                | 🔑 UK
 public     | user_sessions          | user_sessions_session_token_key                | 🔑 UK
 public     | users                  | idx_users_active                               | ✅
 public     | users                  | idx_users_email                                | ✅
 public     | users                  | idx_users_role                                 | ✅
 public     | users                  | users_email_key                                | 🔑 UK
 public     | users                  | users_pkey                                     | 🔑 PK
(69 filas)

⚡ Verificando triggers...
               trigger_name               |       table_name       | action_timing | event_manipulation | status
------------------------------------------+------------------------+---------------+--------------------+--------
 update_notification_templates_updated_at | notification_templates | BEFORE        | UPDATE             | ✅
 update_system_settings_updated_at        | system_settings        | BEFORE        | UPDATE             | ✅
 check_task_completion_trigger            | task_assignments       | AFTER         | UPDATE             | ✅
 log_task_assignment_changes_trigger      | task_assignments       | AFTER         | INSERT             | ✅
 log_task_assignment_changes_trigger      | task_assignments       | AFTER         | UPDATE             | ✅
 update_task_assignee_count_trigger       | task_assignments       | AFTER         | INSERT             | ✅
 update_task_assignee_count_trigger       | task_assignments       | AFTER         | DELETE             | ✅
 update_task_assignee_count_trigger       | task_assignments       | AFTER         | UPDATE             | ✅
 validate_primary_assignment_trigger      | task_assignments       | BEFORE        | UPDATE             | ✅
 validate_primary_assignment_trigger      | task_assignments       | BEFORE        | INSERT             | ✅
 update_task_categories_updated_at        | task_categories        | BEFORE        | UPDATE             | ✅
 log_task_changes_trigger                 | tasks                  | AFTER         | UPDATE             | ✅
 log_task_changes_trigger                 | tasks                  | AFTER         | INSERT             | ✅
 update_tasks_updated_at                  | tasks                  | BEFORE        | UPDATE             | ✅
 update_teams_updated_at                  | teams                  | BEFORE        | UPDATE             | ✅
 update_users_updated_at                  | users                  | BEFORE        | UPDATE             | ✅
(16 filas)

🔧 Verificando funciones...
         function_name          | routine_type | return_type | status
--------------------------------+--------------+-------------+--------
 calculate_user_stats           | FUNCTION     | record      | ✅
         function_name          | routine_type | return_type | status
--------------------------------+--------------+-------------+--------
 calculate_user_stats           | FUNCTION     | record      | ✅
 check_task_completion          | FUNCTION     | trigger     | ✅
 gin_btree_consistent           | FUNCTION     | boolean     | ✅
 gin_compare_prefix_anyenum     | FUNCTION     | integer     | ✅
 gin_compare_prefix_bit         | FUNCTION     | integer     | ✅
 gin_compare_prefix_bool        | FUNCTION     | integer     | ✅
 gin_compare_prefix_bpchar      | FUNCTION     | integer     | ✅
 gin_compare_prefix_bytea       | FUNCTION     | integer     | ✅
 gin_compare_prefix_char        | FUNCTION     | integer     | ✅
 gin_compare_prefix_cidr        | FUNCTION     | integer     | ✅
 gin_compare_prefix_date        | FUNCTION     | integer     | ✅
 gin_compare_prefix_float4      | FUNCTION     | integer     | ✅
 gin_compare_prefix_float8      | FUNCTION     | integer     | ✅
 gin_compare_prefix_inet        | FUNCTION     | integer     | ✅
 gin_compare_prefix_int2        | FUNCTION     | integer     | ✅
 gin_compare_prefix_int4        | FUNCTION     | integer     | ✅
 gin_compare_prefix_int8        | FUNCTION     | integer     | ✅
 gin_compare_prefix_interval    | FUNCTION     | integer     | ✅
 gin_compare_prefix_macaddr     | FUNCTION     | integer     | ✅
 gin_compare_prefix_macaddr8    | FUNCTION     | integer     | ✅
 gin_compare_prefix_money       | FUNCTION     | integer     | ✅
 gin_compare_prefix_name        | FUNCTION     | integer     | ✅
 gin_compare_prefix_numeric     | FUNCTION     | integer     | ✅
 gin_compare_prefix_oid         | FUNCTION     | integer     | ✅
 gin_compare_prefix_text        | FUNCTION     | integer     | ✅
 gin_compare_prefix_time        | FUNCTION     | integer     | ✅
 gin_compare_prefix_timestamp   | FUNCTION     | integer     | ✅
 gin_compare_prefix_timestamptz | FUNCTION     | integer     | ✅
 gin_compare_prefix_timetz      | FUNCTION     | integer     | ✅
 gin_compare_prefix_uuid        | FUNCTION     | integer     | ✅
 gin_compare_prefix_varbit      | FUNCTION     | integer     | ✅
 gin_enum_cmp                   | FUNCTION     | integer     | ✅
 gin_extract_query_anyenum      | FUNCTION     | internal    | ✅
 gin_extract_query_bit          | FUNCTION     | internal    | ✅
 gin_extract_query_bool         | FUNCTION     | internal    | ✅
 gin_extract_query_bpchar       | FUNCTION     | internal    | ✅
 gin_extract_query_bytea        | FUNCTION     | internal    | ✅
 gin_extract_query_char         | FUNCTION     | internal    | ✅
 gin_extract_query_cidr         | FUNCTION     | internal    | ✅
 gin_extract_query_date         | FUNCTION     | internal    | ✅
 gin_extract_query_float4       | FUNCTION     | internal    | ✅
 gin_extract_query_float8       | FUNCTION     | internal    | ✅
 gin_extract_query_inet         | FUNCTION     | internal    | ✅
 gin_extract_query_int2         | FUNCTION     | internal    | ✅
 gin_extract_query_int4         | FUNCTION     | internal    | ✅
 gin_extract_query_int8         | FUNCTION     | internal    | ✅
 gin_extract_query_interval     | FUNCTION     | internal    | ✅
 gin_extract_query_macaddr      | FUNCTION     | internal    | ✅
 gin_extract_query_macaddr8     | FUNCTION     | internal    | ✅
 gin_extract_query_money        | FUNCTION     | internal    | ✅
 gin_extract_query_name         | FUNCTION     | internal    | ✅
 gin_extract_query_numeric      | FUNCTION     | internal    | ✅
 gin_extract_query_oid          | FUNCTION     | internal    | ✅
 gin_extract_query_text         | FUNCTION     | internal    | ✅
 gin_extract_query_time         | FUNCTION     | internal    | ✅
 gin_extract_query_timestamp    | FUNCTION     | internal    | ✅
 gin_extract_query_timestamptz  | FUNCTION     | internal    | ✅
 gin_extract_query_timetz       | FUNCTION     | internal    | ✅
 gin_extract_query_uuid         | FUNCTION     | internal    | ✅
 gin_extract_query_varbit       | FUNCTION     | internal    | ✅
 gin_extract_value_anyenum      | FUNCTION     | internal    | ✅
 gin_extract_value_bit          | FUNCTION     | internal    | ✅
 gin_extract_value_bool         | FUNCTION     | internal    | ✅
 gin_extract_value_bpchar       | FUNCTION     | internal    | ✅
 gin_extract_value_bytea        | FUNCTION     | internal    | ✅
 gin_extract_value_char         | FUNCTION     | internal    | ✅
 gin_extract_value_cidr         | FUNCTION     | internal    | ✅
 gin_extract_value_date         | FUNCTION     | internal    | ✅
 gin_extract_value_float4       | FUNCTION     | internal    | ✅
 gin_extract_value_float8       | FUNCTION     | internal    | ✅
 gin_extract_value_inet         | FUNCTION     | internal    | ✅
 gin_extract_value_int2         | FUNCTION     | internal    | ✅
 gin_extract_value_int4         | FUNCTION     | internal    | ✅
 gin_extract_value_int8         | FUNCTION     | internal    | ✅
 gin_extract_value_interval     | FUNCTION     | internal    | ✅
 gin_extract_value_macaddr      | FUNCTION     | internal    | ✅
 gin_extract_value_macaddr8     | FUNCTION     | internal    | ✅
 gin_extract_value_money        | FUNCTION     | internal    | ✅
 gin_extract_value_name         | FUNCTION     | internal    | ✅
 gin_extract_value_numeric      | FUNCTION     | internal    | ✅
 gin_extract_value_oid          | FUNCTION     | internal    | ✅
 gin_extract_value_text         | FUNCTION     | internal    | ✅
 gin_extract_value_time         | FUNCTION     | internal    | ✅
 gin_extract_value_timestamp    | FUNCTION     | internal    | ✅
 gin_extract_value_timestamptz  | FUNCTION     | internal    | ✅
 gin_extract_value_timetz       | FUNCTION     | internal    | ✅
 gin_extract_value_uuid         | FUNCTION     | internal    | ✅
 gin_extract_value_varbit       | FUNCTION     | internal    | ✅
 gin_numeric_cmp                | FUNCTION     | integer     | ✅
 log_task_assignment_changes    | FUNCTION     | trigger     | ✅
 log_task_changes               | FUNCTION     | trigger     | ✅
 update_session_activity        | FUNCTION     | trigger     | ✅
 update_task_assignee_count     | FUNCTION     | trigger     | ✅
 update_updated_at_column       | FUNCTION     | trigger     | ✅
 validate_primary_assignment    | FUNCTION     | trigger     | ✅
(95 filas)

👁️  Verificando vistas...
     view_name     |   status
-------------------+-------------
 dashboard_metrics | ❌ FALTANTE
 task_statistics   | ❌ FALTANTE
 team_summary      | ❌ FALTANTE
 user_statistics   | ❌ FALTANTE
(4 filas)

🔒 Verificando Row Level Security...
 schemaname |    tablename     | rls_enabled |        status
------------+------------------+-------------+----------------------
 public     | activity_logs    | f           | ❌ RLS Deshabilitado
 public     | notifications    | f           | ❌ RLS Deshabilitado
 public     | task_assignments | f           | ❌ RLS Deshabilitado
 public     | task_attachments | f           | ❌ RLS Deshabilitado
 public     | task_comments    | f           | ❌ RLS Deshabilitado
 public     | tasks            | f           | ❌ RLS Deshabilitado
 public     | users            | f           | ❌ RLS Deshabilitado
(7 filas)

🛡️  Verificando políticas RLS...
 schemaname | tablename | policyname | permissive | roles | cmd | status
------------+-----------+------------+------------+-------+-----+--------
(0 filas)

💾 Verificando datos iniciales...
   table_name    | record_count | status
-----------------+--------------+--------
 system_settings |           13 | ✅
(1 fila)

   table_name    | record_count | status
-----------------+--------------+--------
 task_categories |           10 | ✅
(1 fila)

       table_name       | record_count | status
------------------------+--------------+--------
 notification_templates |            6 | ✅
(1 fila)

✅ Verificando constraints...
       table_name       |                constraint_name                 | constraint_type |    status
------------------------+------------------------------------------------+-----------------+---------------
 activity_logs          | 2200_18045_1_not_null                          | CHECK           | ✅ CHECK
       table_name       |                constraint_name                 | constraint_type |    status
------------------------+------------------------------------------------+-----------------+---------------
 activity_logs          | 2200_18045_1_not_null                          | CHECK           | ✅ CHECK
 activity_logs          | 2200_18045_3_not_null                          | CHECK           | ✅ CHECK
 activity_logs          | 2200_18045_4_not_null                          | CHECK           | ✅ CHECK
 activity_logs          | activity_logs_pkey                             | PRIMARY KEY     | 🗝️ PRIMARY KEY
 generated_reports      | 2200_18082_1_not_null                          | CHECK           | ✅ CHECK
 generated_reports      | 2200_18082_2_not_null                          | CHECK           | ✅ CHECK
 generated_reports      | 2200_18082_3_not_null                          | CHECK           | ✅ CHECK
 generated_reports      | 2200_18082_6_not_null                          | CHECK           | ✅ CHECK
 generated_reports      | generated_reports_pkey                         | PRIMARY KEY     | 🗝️ PRIMARY KEY
 notification_templates | 2200_18002_1_not_null                          | CHECK           | ✅ CHECK
 notification_templates | 2200_18002_2_not_null                          | CHECK           | ✅ CHECK
 notification_templates | 2200_18002_3_not_null                          | CHECK           | ✅ CHECK
 notification_templates | 2200_18002_4_not_null                          | CHECK           | ✅ CHECK
 notification_templates | 2200_18002_5_not_null                          | CHECK           | ✅ CHECK
 notification_templates | 2200_18002_6_not_null                          | CHECK           | ✅ CHECK
 notification_templates | notification_templates_pkey                    | PRIMARY KEY     | 🗝️ PRIMARY KEY
 notification_templates | notification_templates_name_key                | UNIQUE          | 🔑 UNIQUE
 notifications          | 2200_17990_1_not_null                          | CHECK           | ✅ CHECK
 notifications          | 2200_17990_2_not_null                          | CHECK           | ✅ CHECK
 notifications          | 2200_17990_3_not_null                          | CHECK           | ✅ CHECK
 notifications          | 2200_17990_4_not_null                          | CHECK           | ✅ CHECK
 notifications          | 2200_17990_5_not_null                          | CHECK           | ✅ CHECK
 notifications          | 2200_17990_6_not_null                          | CHECK           | ✅ CHECK
 notifications          | notifications_schedule_check                   | CHECK           | ✅ CHECK
 notifications          | notifications_pkey                             | PRIMARY KEY     | 🗝️ PRIMARY KEY
 system_settings        | 2200_18069_1_not_null                          | CHECK           | ✅ CHECK
 system_settings        | 2200_18069_2_not_null                          | CHECK           | ✅ CHECK
 system_settings        | 2200_18069_3_not_null                          | CHECK           | ✅ CHECK
 system_settings        | system_settings_pkey                           | PRIMARY KEY     | 🗝️ PRIMARY KEY
 system_settings        | system_settings_key_key                        | UNIQUE          | 🔑 UNIQUE
 task_assignments       | 2200_17953_1_not_null                          | CHECK           | ✅ CHECK
 task_assignments       | 2200_17953_2_not_null                          | CHECK           | ✅ CHECK
 task_assignments       | 2200_17953_3_not_null                          | CHECK           | ✅ CHECK
 task_assignments       | 2200_17953_5_not_null                          | CHECK           | ✅ CHECK
 task_assignments       | task_assignments_hours_allocated_check         | CHECK           | ✅ CHECK
 task_assignments       | task_assignments_pkey                          | PRIMARY KEY     | 🗝️ PRIMARY KEY
 task_assignments       | task_assignments_task_id_user_id_is_active_key | UNIQUE          | 🔑 UNIQUE
 task_attachments       | 2200_18105_1_not_null                          | CHECK           | ✅ CHECK
 task_attachments       | 2200_18105_2_not_null                          | CHECK           | ✅ CHECK
 task_attachments       | 2200_18105_3_not_null                          | CHECK           | ✅ CHECK
 task_attachments       | 2200_18105_4_not_null                          | CHECK           | ✅ CHECK
 task_attachments       | 2200_18105_5_not_null                          | CHECK           | ✅ CHECK
 task_attachments       | 2200_18105_6_not_null                          | CHECK           | ✅ CHECK
 task_attachments       | 2200_18105_7_not_null                          | CHECK           | ✅ CHECK
 task_attachments       | 2200_18105_8_not_null                          | CHECK           | ✅ CHECK
 task_attachments       | task_attachments_file_size_check               | CHECK           | ✅ CHECK
 task_attachments       | task_attachments_file_size_limit               | CHECK           | ✅ CHECK
 task_attachments       | task_attachments_pkey                          | PRIMARY KEY     | 🗝️ PRIMARY KEY
 task_categories        | 2200_17869_1_not_null                          | CHECK           | ✅ CHECK
 task_categories        | 2200_17869_2_not_null                          | CHECK           | ✅ CHECK
 task_categories        | task_categories_color_format                   | CHECK           | ✅ CHECK
 task_categories        | task_categories_pkey                           | PRIMARY KEY     | 🗝️ PRIMARY KEY
 task_comments          | 2200_18093_1_not_null                          | CHECK           | ✅ CHECK
 task_comments          | 2200_18093_2_not_null                          | CHECK           | ✅ CHECK
 task_comments          | 2200_18093_3_not_null                          | CHECK           | ✅ CHECK
 task_comments          | 2200_18093_4_not_null                          | CHECK           | ✅ CHECK
 task_comments          | task_comments_content_length                   | CHECK           | ✅ CHECK
 task_comments          | task_comments_pkey                             | PRIMARY KEY     | 🗝️ PRIMARY KEY
 tasks                  | 2200_17896_17_not_null                         | CHECK           | ✅ CHECK
 tasks                  | 2200_17896_1_not_null                          | CHECK           | ✅ CHECK
 tasks                  | 2200_17896_2_not_null                          | CHECK           | ✅ CHECK
 tasks                  | 2200_17896_4_not_null                          | CHECK           | ✅ CHECK
 tasks                  | 2200_17896_6_not_null                          | CHECK           | ✅ CHECK
 tasks                  | 2200_17896_7_not_null                          | CHECK           | ✅ CHECK
 tasks                  | tasks_actual_hours_check                       | CHECK           | ✅ CHECK
 tasks                  | tasks_completion_logic                         | CHECK           | ✅ CHECK
 tasks                  | tasks_completion_percentage_check              | CHECK           | ✅ CHECK
 tasks                  | tasks_cost_check                               | CHECK           | ✅ CHECK
 tasks                  | tasks_due_date_future                          | CHECK           | ✅ CHECK
 tasks                  | tasks_estimated_hours_check                    | CHECK           | ✅ CHECK
 tasks                  | tasks_title_length                             | CHECK           | ✅ CHECK
 tasks                  | tasks_pkey                                     | PRIMARY KEY     | 🗝️ PRIMARY KEY
 team_memberships       | 2200_17844_1_not_null                          | CHECK           | ✅ CHECK
 team_memberships       | 2200_17844_2_not_null                          | CHECK           | ✅ CHECK
 team_memberships       | 2200_17844_3_not_null                          | CHECK           | ✅ CHECK
 team_memberships       | team_memberships_pkey                          | PRIMARY KEY     | 🗝️ PRIMARY KEY
 team_memberships       | team_memberships_user_id_team_id_key           | UNIQUE          | 🔑 UNIQUE
 teams                  | 2200_17819_1_not_null                          | CHECK           | ✅ CHECK
 teams                  | 2200_17819_2_not_null                          | CHECK           | ✅ CHECK
 teams                  | 2200_17819_4_not_null                          | CHECK           | ✅ CHECK
 teams                  | teams_slug_format                              | CHECK           | ✅ CHECK
 teams                  | teams_pkey                                     | PRIMARY KEY     | 🗝️ PRIMARY KEY
 teams                  | teams_slug_key                                 | UNIQUE          | 🔑 UNIQUE
 user_sessions          | 2200_18054_10_not_null                         | CHECK           | ✅ CHECK
 user_sessions          | 2200_18054_1_not_null                          | CHECK           | ✅ CHECK
 user_sessions          | 2200_18054_2_not_null                          | CHECK           | ✅ CHECK
 user_sessions          | 2200_18054_3_not_null                          | CHECK           | ✅ CHECK
 user_sessions          | user_sessions_pkey                             | PRIMARY KEY     | 🗝️ PRIMARY KEY
 user_sessions          | user_sessions_refresh_token_key                | UNIQUE          | 🔑 UNIQUE
 user_sessions          | user_sessions_session_token_key                | UNIQUE          | 🔑 UNIQUE
 users                  | 2200_17787_1_not_null                          | CHECK           | ✅ CHECK
 users                  | 2200_17787_2_not_null                          | CHECK           | ✅ CHECK
 users                  | 2200_17787_3_not_null                          | CHECK           | ✅ CHECK
 users                  | 2200_17787_4_not_null                          | CHECK           | ✅ CHECK
 users                  | users_email_format                             | CHECK           | ✅ CHECK
 users                  | users_name_length                              | CHECK           | ✅ CHECK
 users                  | users_pkey                                     | PRIMARY KEY     | 🗝️ PRIMARY KEY
 users                  | users_email_key                                | UNIQUE          | 🔑 UNIQUE
(98 filas)

🧪 Ejecutando pruebas funcionales...
psql:supabase/migrations/validate_migrations.sql:273: NOTICE:  ✅ Función calculate_user_stats ejecutada correctamente
DO
^[[Bpsql:supabase/migrations/validate_migrations.sql:291: ERROR:  relation "user_statistics" does not exist
LÍNEA 1: SELECT COUNT(*)                FROM user_statistics
                                             ^
CONSULTA:  SELECT COUNT(*)                FROM user_statistics
CONTEXTO:  PL/pgSQL function inline_code_block line 5 at SQL statement
📊 RESUMEN DE VALIDACIÓN
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:  ===========================================
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:  🎉 VALIDACIÓN COMPLETADA
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:  ===========================================
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:  📋 Tablas creadas: 14
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:  👁️  Vistas creadas: 0
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:  🔧 Funciones creadas: 95
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:  ⚡ Triggers activos: 16
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:  🛡️  Políticas RLS: 0
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:  ⚠️  ALGUNOS COMPONENTES PODRÍAN ESTAR FALTANDO
^[[Bpsql:supabase/migrations/validate_migrations.sql:346: NOTICE:  🔍 Revisar logs anteriores para identificar problemas
psql:supabase/migrations/validate_migrations.sql:346: NOTICE:  ===========================================
DO
         mensaje          |           timestamp           | ejecutado_por |                                 postgresql_version
--------------------------+-------------------------------+---------------+------------------------------------------------------------------------------------
 🎯 Validación completada | 2025-06-30 01:16:50.133064+00 | postgres      | PostgreSQL 15.8 on aarch64-unknown-linux-gnu, compiled by gcc (GCC) 13.2.0, 64-bit
(1 fila)

```

**Visualiza las tables en Supabase**

![image.png](%F0%9F%93%9A%20README%20-%20DB%20Migrations%202214fbea3fce8006b212c32f487f3c93/image%202.png)

![image.png](%F0%9F%93%9A%20README%20-%20DB%20Migrations%202214fbea3fce8006b212c32f487f3c93/image%203.png)

![image.png](%F0%9F%93%9A%20README%20-%20DB%20Migrations%202214fbea3fce8006b212c32f487f3c93/image%204.png)

## 5. Creacion de la base de datos (automatica)

### `supabase db pull`

Descarga el esquema actual de tu base de datos remota y lo guarda en `supabase/schema.sql`, actualizando tu copia local.

```bash

# Trae el esquema remoto y lo sobreescribe en supabase/schema.sql
supabase db pull

# Útil para sincronizar después de crear tablas o extensiones vía la UI de Supabase

```

---

### `supabase db push`

Aplica todas las migraciones `.sql` que tengas en `supabase/migrations/` (y subcarpetas) contra tu proyecto remoto, marcándolas como ejecutadas.

```bash

# Enlaza el proyecto remoto (si aún no lo hiciste) y aplica nuevas migraciones
supabase link --project-ref <tu-ref>
supabase db push

# Para simular sin aplicar cambios:
supabase db push --dry-run
```

---

**Ejecutar migraciones para mayor control (o no usas el CLI)**

Puedes recorrer manualmente las carpetas y pasar cada archivo a `psql` usando un pequeño *bash loop*. Por ejemplo, asumiendo que ya tienes tu `DATABASE_URL` exportada:

```bash

export DATABASE_URL="postgresql://postgres:TU_PASS@db.proyecto.supabase.co:5432/postgres"

# Aplica todos los DDL primero
for f in $(find supabase/migrations/DDL -type f -name '*.sql' | sort); do
  echo "🗂 Aplicando DDL: $f"
  psql "$DATABASE_URL" -f "$f"
done

# Luego los DML
for f in $(find supabase/migrations/DML -type f -name '*.sql' | sort); do
  echo "🗂 Aplicando DML: $f"
  psql "$DATABASE_URL" -f "$f"
done
```

O bien en un sólo *one-liner* (aplica en una sola pasada todo lo que haya bajo `migrations`):

```bash

find supabase/migrations -type f -name '*.sql' | sort \
  | xargs -L1 -I{} psql "$DATABASE_URL" -f {}
```

### `supabase db reset`

Borra y vuelve a crear tu base de datos **local** para volverla al estado de todas las migraciones aplicadas (NO toca el remoto).

```bash

# Elimina la instancia local y la recrea con las migraciones
supabase db reset

# Combínalo con start para ciclos rápidos
supabase db reset && supabase db start
```

---

### 6. iniciar insta de base de datos con `supabase db start`

Levanta una instancia local de Postgres (Docker) configurada como tu proyecto Supabase, ideal para desarrollo en tu máquina.

```bash

# Arranca el Postgres local, escuchando en el puerto por defecto (5432)
supabase db start

# Luego puedes conectarte con psql:
psql postgres://postgres:postgres@localhost:5432/postgres
```

---

Con estos comandos tienes cubierto todo el flujo de ciclo de vida de tu esquema SQL: desde desarrollo (`start`/`reset`), validación (`lint`), sincronización (`pull`/`diff`), hasta despliegue de migraciones (`push`) y dumps (`dump`).

**Opción 1:** Con `supabase db connect` + `\i`

```bash

# Abre un shell psql interactivo apuntando a tu Supabase
supabase db connect
```

Dentro del prompt de `psql`:

```sql

-- Aplica un archivo concreto
\i supabase/migrations/DDL/20241201000001_initial_setup.sql

-- O todos de una carpeta
\i supabase/migrations/DDL/*.sql
\i supabase/migrations/DML/*.sql
```

**Opción 2:** Ejecutar migraciones una por una (recomendado para producción)

```bash
# 1. Ejecutar cada migración individualmente
supabase db push --file supabase/migrations/20241201000001_initial_setup.sql

# 2. Ejecutar scripts DDL para crear entidades
supabase db push --file supabase/migrations/DDL/20241201000002_create_users_table.sql
...

# 3. Ejecutar scripts DML para inserir datos
supabase db push --file supabase/migrations/DDL/20241201000012_insert_initial_data.sql
...

# 4. Ejecutar scripts para verificar que la estructura esté completa y funcional
supabase db push --file validate_migrations.sql
```

**Opción 3:** Ejecutar todas las migraciones automáticamente

```bash
# Copiar archivos de migración al directorio correcto
cp *.sql supabase/migrations/

# Ejecutar migraciones
supabase db push

# O ejecutar localmente primero para pruebas
supabase start
supabase db reset
```

---

### Recapitulando

- **`supabase db push`**: lee recursivamente `supabase/migrations/` (incluidas subcarpetas) y aplica las migraciones en orden de nombre.
- **`psql -f`** + *bash*: te da control total sobre el orden (por carpetas, por tipos de migración, etc.), útil si tu flujo requiere DDL primero y DML después.

### Verificación Post-Migración

**Verificar estructura de la base de datos**

```sql
-- Contar tablas creadas
SELECT COUNT(*) as total_tables
FROM information_schema.tables
WHERE table_schema = 'public' AND table_type = 'BASE TABLE';

-- Verificar ENUMs creados
SELECT typname FROM pg_type WHERE typtype = 'e';

-- Verificar triggers
SELECT trigger_name, event_manipulation, event_object_table
FROM information_schema.triggers
WHERE trigger_schema = 'public';
```

**Verificar datos iniciales**

```sql
-- Verificar configuraciones del sistema
SELECT key, value FROM system_settings;

-- Verificar categorías de tareas
SELECT name, color FROM task_categories WHERE is_active = true;

-- Verificar templates de notificación
SELECT name, type, channel FROM notification_templates WHERE is_active = true;

```

## Deployment de aplicacion

```bash
(base) geoffreyporto@Mac-Studio-de-Geoffrey puul-tasks-api % npm run start

> puul-tasks-api@0.0.1 start
> nest start

[Nest] 28590  - 29/06/2025, 18:42:48     LOG [NestFactory] Starting Nest application...
[Nest] 28590  - 29/06/2025, 18:42:48     LOG [InstanceLoader] AppModule dependencies initialized +5ms
[Nest] 28590  - 29/06/2025, 18:42:48     LOG [RoutesResolver] AppController {/}: +2ms
[Nest] 28590  - 29/06/2025, 18:42:48     LOG [RouterExplorer] Mapped {/, GET} route +1ms
[Nest] 28590  - 29/06/2025, 18:42:48     LOG [NestApplication] Nest application successfully started +1ms
```

## Troubleshooting

### Problemas Comunes

### Error: "relation does not exist"

- **Causa**: Archivo ejecutado fuera de orden
- **Solución**: Ejecutar migraciones en el orden correcto (001 → 012)

### Error: "type does not exist"

- **Causa**: ENUMs no creados
- **Solución**: Asegurar que `20241201000001_initial_setup.sql` se ejecutó correctamente

### Error: "permission denied"

- **Causa**: Problemas con RLS
- **Solución**: Verificar que las políticas RLS se aplicaron correctamente

### Error: "function does not exist"

- **Causa**: Triggers/funciones no creados
- **Solución**: Verificar ejecución de `20241201000010_create_triggers_and_functions.sql`

### Rollback de Migraciones

```bash
# Ver historial de migraciones
supabase migration list

# Revertir a estado anterior (cuidado en producción)
supabase db reset

# Hacer backup antes de cambios importantes
pg_dump YOUR_DATABASE_URL > backup_$(date +%Y%m%d_%H%M%S).sql

```

## Consideraciones de Producción

### Seguridad

1. **Cambiar contraseña del usuario admin** en `20241201000012_insert_initial_data.sql`
2. **Revisar políticas RLS** antes de despliegue
3. **Configurar variables de entorno** para credenciales sensibles

### Performance

1. **Monitorear índices** después del despliegue
2. **Ajustar configuraciones** en `system_settings` según necesidades
3. **Revisar planes de VACUUM y ANALYZE**

### Monitoreo

1. **Configurar alertas** para tablas de logs
2. **Revisar métricas** en las vistas de analítica
3. **Monitorear uso de storage** para archivos adjuntos

## Estructura de Datos Resultante

### Tablas Principales

- `users` (15 campos)
- `tasks` (21 campos)
- `task_assignments` (11 campos)
- `teams` (8 campos)
- `notifications` (18 campos)

### Características del Sistema

- **Row Level Security (RLS)** habilitado
- **Auditoría completa** de cambios
- **Sistema de notificaciones** configurable
- **Métricas y analíticas** en tiempo real
- **Gestión de archivos** adjuntos
- **Multi-tenancy** con equipos
- **Roles y permisos** granulares

## Soporte

Para problemas específicos con las migraciones:

1. Revisar logs de Supabase: `supabase logs db`
2. Verificar orden de ejecución de archivos
3. Consultar documentación de Supabase CLI: https://supabase.com/docs/reference/cli

### Archivos de Soporte:

- **`README_migrations.md`** - Documentación completa
- **`validate_migrations.sql`** - Script de validación

### Características Implementadas:

- **✅ Dependencias resueltas** - Cada archivo respeta el orden de dependencias
- **✅ RLS habilitado** - Políticas de seguridad para Supabase Auth
- **✅ Triggers automáticos** - Logging, contadores, validaciones
- **✅ Datos iniciales** - Categorías, templates, configuraciones
- **✅ Vistas de analítica** - Estadísticas listas para usar
- **✅ Validación completa** - Script para verificar la instalación

### Beneficios del Enfoque Modular:

1. **Rollback granular** - Posibilidad de revertir cambios específicos
2. **Debugging simplificado** - Fácil identificación de errores por archivo
3. **Desarrollo incremental** - Aplicar cambios paso a paso
4. **Mantenimiento** - Modificaciones aisladas sin afectar otras tablas
5. **CI/CD friendly** - Integración sencilla en pipelines