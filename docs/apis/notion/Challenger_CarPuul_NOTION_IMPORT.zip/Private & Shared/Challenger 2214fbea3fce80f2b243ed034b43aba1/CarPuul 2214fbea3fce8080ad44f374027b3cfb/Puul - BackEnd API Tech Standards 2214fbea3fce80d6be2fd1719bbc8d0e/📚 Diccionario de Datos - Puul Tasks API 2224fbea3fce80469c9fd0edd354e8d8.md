# 📚 Diccionario de Datos - Puul Tasks API

Owner: Geoffrey Porto

## 🏛️ Información General

- **Base de Datos**: PostgreSQL 15.8 (Supabase)
- **Esquema**: public
- **Autor**: Puul Development Team
- **Versión**: 1.0
- **Fecha**: 2025

---

## 📊 Resumen Estadístico

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image.png)

---

## 🔤 Enumeraciones (ENUMs)

### user_role

**Descripción**: Roles disponibles para usuarios del sistema

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%201.png)

### task_status

**Descripción**: Estados posibles de una tarea

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%202.png)

### task_priority

**Descripción**: Niveles de prioridad para tareas

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%203.png)

### notification_type

**Descripción**: Tipos de notificaciones del sistema

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%204.png)

### notification_status

**Descripción**: Estados de las notificaciones

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%205.png)

### notification_channel

**Descripción**: Canales de entrega de notificaciones

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%206.png)

---

## 🗂️ Tablas del Sistema

### 1. users

**Descripción**: Almacena información de usuarios del sistema

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%207.png)

**Índices**:

- `users_pkey` (PRIMARY KEY): id
- `users_email_key` (UNIQUE): email
- `idx_users_email`: email
- `idx_users_role`: role
- `idx_users_active`: is_active (WHERE is_active = true)

**Constraints**:

- `users_email_format`: Validación de formato de email
- `users_name_length`: Nombre entre 2 y 255 caracteres

---

### 2. teams

**Descripción**: Equipos o departamentos para organización multitenancy

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%208.png)

**Constraints**:

- `teams_slug_format`: Slug solo con letras minúsculas, números y guiones

---

### 3. team_memberships

**Descripción**: Relación muchos a muchos entre usuarios y equipos

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%209.png)

**Constraints**:

- `UNIQUE(user_id, team_id)`: Un usuario no puede estar duplicado en un equipo

---

### 4. task_categories

**Descripción**: Categorías para clasificar tareas

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2010.png)

**Constraints**:

- `task_categories_color_format`: Color en formato hexadecimal válido

---

### 5. tasks ⭐ (Tabla Principal)

**Descripción**: Tabla central que almacena todas las tareas del sistema

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2011.png)

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2012.png)

**Índices**:

- `tasks_pkey` (PRIMARY KEY): id
- `idx_tasks_status`: status
- `idx_tasks_due_date`: due_date
- `idx_tasks_created_at`: created_at DESC
- `idx_tasks_team_id`: team_id
- `idx_tasks_category_id`: category_id
- `idx_tasks_created_by`: created_by
- `idx_tasks_status_due_date`: (status, due_date)
- `idx_tasks_team_status`: (team_id, status)

**Constraints**:

- `tasks_title_length`: Título entre 3 y 500 caracteres
- `tasks_due_date_future`: Fecha de vencimiento posterior a la creación
- `tasks_completion_logic`: Lógica de estado completed vs completed_at

---

### 6. task_assignments ⭐

**Descripción**: Asignaciones de usuarios a tareas (relación muchos a muchos)

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2013.png)

**Índices**:

- `task_assignments_pkey` (PRIMARY KEY): id
- `idx_task_assignments_task_id`: task_id
- `idx_task_assignments_user_id`: user_id
- `idx_task_assignments_active`: is_active (WHERE is_active = true)

**Constraints**:

- `UNIQUE(task_id, user_id, is_active)`: Un usuario activo por tarea

---

### 7. notifications

**Descripción**: Sistema de notificaciones del sistema

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2014.png)

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2015.png)

**Índices**:

- `notifications_pkey` (PRIMARY KEY): id
- `idx_notifications_user_id`: user_id
- `idx_notifications_status`: status
- `idx_notifications_scheduled_for`: scheduled_for
- `idx_notifications_task_id`: task_id (WHERE task_id IS NOT NULL)

---

### 8. notification_templates

**Descripción**: Templates reutilizables para notificaciones

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2016.png)

---

### 9. activity_logs

**Descripción**: Registro de actividades y auditoría del sistema

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2017.png)

**Índices**:

- `activity_logs_pkey` (PRIMARY KEY): id
- `idx_activity_logs_user_id_time`: (user_id, occurred_at DESC)
- `idx_activity_logs_resource`: (resource_type, resource_id)
- `idx_activity_logs_time`: occurred_at DESC

---

### 10. user_sessions

**Descripción**: Gestión de sesiones de usuario

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2018.png)

---

### 11. system_settings

**Descripción**: Configuraciones globales del sistema

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2019.png)

---

### 12. generated_reports

**Descripción**: Reportes generados por el sistema

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2020.png)

---

### 13. task_comments

**Descripción**: Comentarios en tareas

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2021.png)

**Constraints**:

- `task_comments_content_length`: Contenido entre 1 y 5000 caracteres

---

### 14. task_attachments

**Descripción**: Archivos adjuntos a tareas

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2022.png)

**Constraints**:

- `task_attachments_file_size_limit`: Límite de 50MB por archivo

---

## 👁️ Vistas del Sistema

### user_statistics

**Descripción**: Estadísticas calculadas por usuario

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2023.png)

### task_statistics

**Descripción**: Estadísticas de tareas por semana

![image.png](%F0%9F%93%9A%20Diccionario%20de%20Datos%20-%20Puul%20Tasks%20API%202224fbea3fce80469c9fd0edd354e8d8/image%2024.png)

---

## 🔧 Triggers y Automatización

### 1. update_updated_at_column()

**Descripción**: Actualiza automáticamente el campo `updated_at`**Tablas**: users, tasks, teams, task_categories, notification_templates, system_settings

### 2. update_task_assignee_count()

**Descripción**: Mantiene actualizado el contador de asignados en tasks
**Tabla**: task_assignments
**Evento**: INSERT, UPDATE, DELETE

### 3. log_task_changes()

**Descripción**: Registra automáticamente cambios en tareas
**Tabla**: tasks
**Evento**: INSERT, UPDATE
**Destino**: activity_logs

---

## 🔒 Políticas de Seguridad (RLS)

### Row Level Security habilitado en:

- users
- tasks
- task_assignments
- notifications
- activity_logs

### Políticas principales:

1. **"Users can view own profile"**: Los usuarios ven su propio perfil
2. **"Users can update own profile"**: Los usuarios pueden actualizar su perfil
3. **"Admins can view all users"**: Los admins ven todos los usuarios
4. **"Users can view assigned tasks"**: Los usuarios ven tareas asignadas a ellos

---

## 📈 Consideraciones de Performance

### Índices Optimizados:

- **Búsquedas por email**: users(email)
- **Filtros de tareas**: tasks(status, due_date)
- **Asignaciones activas**: task_assignments(is_active)
- **Notificaciones pendientes**: notifications(status, scheduled_for)
- **Logs por usuario**: activity_logs(user_id, occurred_at)

### Particionamiento Recomendado:

- **activity_logs**: Por fecha (mensual)
- **notifications**: Por fecha (mensual)
- **generated_reports**: Por fecha (trimestral)

---

## 🚀 Configuraciones de Supabase

### Extensiones Requeridas:

- `uuid-ossp`: Generación de UUIDs
- `pgcrypto`: Funciones criptográficas
- `btree_gin`: Índices optimizados para JSONB

### Features de Supabase Utilizados:

- **Row Level Security (RLS)**: Seguridad a nivel de fila
- **Real-time**: Para notificaciones en tiempo real
- **Storage**: Para archivos adjuntos
- **Auth**: Integración con sistema de autenticación

---

## 📊 Métricas de Calidad

### Normalización:

- **3ra Forma Normal**: ✅ Cumplido
- **Dependencias Funcionales**: ✅ Resueltas
- **Redundancia**: ✅ Minimizada

### Integridad:

- **Referencial**: ✅ Foreign Keys configuradas
- **Dominio**: ✅ Constraints y checks implementados
- **Entidad**: ✅ Primary Keys en todas las tablas

### Mantenibilidad:

- **Documentación**: ✅ Completa
- **Naming Convention**: ✅ Consistente
- **Versionado**: ✅ Control de cambios

---