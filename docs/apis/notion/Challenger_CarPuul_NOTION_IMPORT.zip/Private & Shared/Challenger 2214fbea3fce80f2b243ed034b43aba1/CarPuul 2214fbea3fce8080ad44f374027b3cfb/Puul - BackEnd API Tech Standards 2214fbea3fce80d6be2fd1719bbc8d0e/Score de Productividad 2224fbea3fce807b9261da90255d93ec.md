# Score de Productividad

Owner: Geoffrey Porto

## Cálculo del Score de Productividad

La fórmula para calcular el score de productividad ($S_p$) se define a partir de las siguientes variables, donde:

- N_c: Número total de tareas completadas. **Se otorgan 10 puntos** por cada tarea completada.
- N_v: Número total de tareas activas y vencidas. **Se restan 5 puntos** por cada tarea activa que ya ha pasado su fecha de entrega.
- K_c: Costo total acumulado de las tareas completadas. **Se añade un bono equivalente al 1%** del costo total de las tareas completadas.
- N_t: Número total de tareas.

Matemáticamente, se puede expresar como una función por partes de la siguiente manera:

$$
S_p = \begin{cases} \text{round}\left( (N_c \cdot 10) - (N_v \cdot 5) + \frac{K_c}{100} \right) & \text{si } N_t > 0 \\ 0 & \text{si } N_t = 0 \end{cases}
$$

Donde `round()` es la función de redondeo al entero más cercano.

**Desglose de la fórmula:**

1. **(N_c \c . 10)**: Se otorgan 10 puntos por cada tarea completada.
2. **(N_v \c . 5)**: Se restan 5 puntos por cada tarea activa que ya ha pasado su fecha de entrega.
3. **\frac{K_c}{100}**: Se añade un bono equivalente al 1% del costo total de las tareas completadas.
4. **$\text{round}(\dots)$**: El resultado final se redondea al entero más cercano.
5. La condición **$\text{si } N_t > 0$** asegura que el cálculo solo se realice si existen tareas; de lo contrario, el score es **0**. Si no hay tareas (\(N=0\)), el puntaje es 0.