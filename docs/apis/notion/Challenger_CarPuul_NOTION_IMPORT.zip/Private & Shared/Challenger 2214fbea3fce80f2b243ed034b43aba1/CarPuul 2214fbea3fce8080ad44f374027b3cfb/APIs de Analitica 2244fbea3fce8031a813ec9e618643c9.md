# APIs de Analitica

Owner: Geoffrey Porto

1. **Distribución de estado de tareas**
    
    ```
    
    GET /api/v1/analytics/tasks/status-distribution
      ?start_date=YYYY-MM-DD
      &end_date=YYYY-MM-DD
    ```
    
    **Qué devuelve:** conteo de tareas en cada estado (“not started”, “in progress”, “completed”) en el rango dado.
    
    **Uso:** detectar rápidamente cuántas tareas siguen pendientes o en curso.
    
    ![image.png](APIs%20de%20Analitica%202244fbea3fce8031a813ec9e618643c9/image.png)
    
2. **Tasa de finalización** 

      Aqui la propuesta seria modificar el standard de las URIs para traer estadisticas en funcion del proyecto y/o team, bajo el formato:   /api/v1/projects/{project_id}/… y/o /api/v1/projects/{project_id}/team_id/…

```

GET /api/v1/projects/{project_id}/analytics/tasks/completion-rate
  ?start_date=YYYY-MM-DD
  &end_date=YYYY-MM-DD
```

**Qué devuelve:** porcentaje de tareas completadas vs. creadas en el período.

**Uso:** medir productividad global y tendencias semanales/mensuales de entrega. 

1. **Tiempo medio de ciclo**
    
    ```
    
    GET /api/v1/projects/{project_id}/analytics/tasks/average-cycle-time
      ?start_date=YYYY-MM-DD
      &end_date=YYYY-MM-DD
    ```
    
    **Qué devuelve:** promedio de `(completed_ts – created_ts)` para tareas terminadas en el rango.
    
    **Uso:** evaluar la rapidez con que el equipo avanza tareas de principio a fin.
    
2. **Burndown de tareas**
    
    ```
    
    GET /api/v1/projects/{project_id}/analytics/tasks/burndown
      ?sprint_start=YYYY-MM-DD
      &sprint_end=YYYY-MM-DD
    ```
    
    **Qué devuelve:** serie temporal de tareas pendientes remanentes al cierre de cada día del sprint.
    
    **Uso:** visualizar el ritmo de consumo de backlog y anticipar si se cumplirá el sprint.
    
3. **Throughput (rendimiento) por periodo**
    
    ```
    
    GET /api/v1/projects/{project_id}/analytics/tasks/throughput
      ?period=daily|weekly|monthly
      &start_date=YYYY-MM-DD
      &end_date=YYYY-MM-DD
    ```
    
    **Qué devuelve:** número de tareas completadas en cada intervalo (día, semana o mes).
    
    **Uso:** comparar ciclos de entrega y planificar capacidad futura.
    
4. **Tareas vencidas**
    
    ```
    http
    CopiarEditar
    GET /api/v1/projects/{project_id}/analytics/tasks/overdue-count
      ?as_of=YYYY-MM-DD
    ```
    
    **Qué devuelve:** conteo de tareas cuya `due_ts` < `as_of` y `status` ≠ completed.
    
    **Uso:** alertar sobre bloqueos y reasignar esfuerzos. [freedcamp.com](https://freedcamp.com/help_/tutorials/wiki/wiki_public/view/DFaab)
    
5. **Desempeño por miembro**
    
    ```
    
    GET /api/v1/projects/{project_id}/analytics/assignees/performance
      ?start_date=YYYY-MM-DD
      &end_date=YYYY-MM-DD
    ```
    
    **Qué devuelve:** para cada usuario asignado, número de tareas completadas y ciclo medio.
    
    **Uso:** identificar cuellos de botella o necesidad de soporte individual. [freedcamp.com](https://freedcamp.com/help_/tutorials/wiki/wiki_public/view/DFaab)
    
6. **Visión general de proyecto**
    
    ```
    
    GET /api/v1/projects/{project_id}/analytics/overview
      ?f_for_overview_app=1
    ```
    
    **Qué devuelve:** datos agregados de estado, fechas clave y custom fields (equivalente a `/overviews/{project_id}`)
    
    **Uso:** tablero único donde el Scrum Master ve alertas, bloqueos y KPIs principales.